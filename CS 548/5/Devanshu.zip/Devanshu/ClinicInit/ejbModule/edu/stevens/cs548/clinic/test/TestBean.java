package edu.stevens.cs548.clinic.test;

import javax.ejb.LocalBean;
import javax.ejb.Singleton;

/**
 * Session Bean implementation class TestBean
 */
@Singleton
@LocalBean
public class TestBean {

    /**
     * Default constructor. 
     */
    public TestBean() {
        // TODO Auto-generated constructor stub
    }

}
