package edu.stevens.cs548.clinic.billing.service;

import javax.ejb.Remote;

@Remote
public interface IBillingServiceRemote extends IBillingService {

}
