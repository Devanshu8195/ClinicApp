package edu.stevens.cs548.clinic.domain;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2017-12-02T17:24:58.502-0500")
@StaticMetamodel(RadiologyDate.class)
public class RadiologyDate_ {
	public static volatile SingularAttribute<RadiologyDate, Date> date;
}
