package edu.stevens.cs548.clinic.service.ejb;

import javax.ejb.Remote;

@Remote
public interface IProviderServiceRemote extends IProviderService {

}
