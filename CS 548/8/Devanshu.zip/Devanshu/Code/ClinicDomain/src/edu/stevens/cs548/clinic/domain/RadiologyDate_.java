package edu.stevens.cs548.clinic.domain;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2017-11-25T08:20:30.245-0500")
@StaticMetamodel(RadiologyDate.class)
public class RadiologyDate_ {
	public static volatile SingularAttribute<RadiologyDate, Date> date;
}
